import React from 'react';
import { Navigate } from 'react-router-dom';

export default function ProtectedRoute({ children }) {
  // SIMULACIÓN: Cambia estos valores para probar el comportamiento
  const isAuthenticated = true; // ¿El usuario inició sesión?
  const userRole = 'admin';     // ¿Qué rol tiene? ('admin' o 'user')

  // 1. Si no está autenticado, directo al login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // 2. Si está autenticado pero NO es admin, puedes mandarlo a una página de error o al login
  if (userRole !== 'admin') {
    alert('No tienes permisos para acceder a esta sección.');
    return <Navigate to="/login" replace />;
  }

  // 3. Si todo está bien, renderiza el panel de usuarios
  return children;
}