import React, { useState } from 'react';
import './AdminStyles.css';

export default function PanelUsuarios() {
  // Datos de prueba para mostrar en la tabla
  const [users, setUsers] = useState([
    { id: 1, name: 'Juan Pérez', email: 'juan@ejemplo.com', role: 'Administrador', status: 'Activo' },
    { id: 2, name: 'María López', email: 'maria@ejemplo.com', role: 'Usuario', status: 'Activo' },
    { id: 3, name: 'Carlos Gómez', email: 'carlos@ejemplo.com', role: 'Usuario', status: 'Inactivo' },
  ]);

  // Función de ejemplo para eliminar un usuario
  const handleDelete = (id) => {
    if (confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
      setUsers(users.filter(user => user.id !== id));
    }
  };

  return (
    <div className="dashboard-container">
      {/* BARRA LATERAL */}
      <aside className="sidebar">
        <div className="sidebar-brand">AdminPanel</div>
        <nav className="sidebar-menu">
          <a href="#users" className="active">Usuarios</a>
          <a href="/login" className="logout-link">Cerrar Sesión</a>
        </nav>
      </aside>

      {/* CONTENIDO PRINCIPAL */}
      <main className="main-content">
        <header className="main-header">
          <h1>Gestión de Usuarios</h1>
        </header>

        {/* TABLA DE USUARIOS */}
        <div className="table-container">
          <table className="admin-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td><strong>{user.name}</strong></td>
                  <td>{user.email}</td>
                  <td><span className="badge-role">{user.role}</span></td>
                  <td>
                    <button className="btn-action edit" onClick={() => alert(`Editar ${user.name}`)}>
                      Editar
                    </button>
                    <button className="btn-action delete" onClick={() => handleDelete(user.id)}>
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}