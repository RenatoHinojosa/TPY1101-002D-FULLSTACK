import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';

// Importaciones apuntando a tu carpeta assets/Pages
import Login from './assets/Pages/Login';
import Register from './assets/Pages/Register';
import PanelUsuarios from './assets/Pages/PanelUsuarios';
import ProtectedRoute from './assets/Components/ProtectedRoute';



const router = createBrowserRouter([
  {
    path: "/",
    element: <Navigate to="/login" replace />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/register",
    element: <Register />,
  },
  {
    path: "/panel", 
    
    element: (
    <ProtectedRoute>
      <PanelUsuarios />
      </ProtectedRoute>), 
  },
  {
    path: "*",
    element: <div style={{ padding: "20px" }}><h2>404 - No encontrado</h2></div>,
  }
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);