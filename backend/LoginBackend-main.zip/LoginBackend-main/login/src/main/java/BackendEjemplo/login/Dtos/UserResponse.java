package BackendEjemplo.login.Dtos;

import BackendEjemplo.login.model.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {
    private Long id;
     private String nombre;
    private  String apellido;
    private String email;

    public static UserResponse from(User user) {
        if (user == null) {
            return null;
        }
        return new UserResponse(
                user.getIdUser(), // Recuerda que en tu modelo User lo llamaste 'idUser'
                user.getNombre(),
                user.getApellido(),
                user.getEmail()
        );
    }

}
