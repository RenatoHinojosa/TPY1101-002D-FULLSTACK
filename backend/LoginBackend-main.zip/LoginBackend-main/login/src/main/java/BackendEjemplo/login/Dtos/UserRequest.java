package BackendEjemplo.login.Dtos;

import BackendEjemplo.login.model.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class UserRequest {
    @NotBlank(message = "El nombre es requerido")
    @Size(max = 80)
    String nombre;

    @NotBlank(message = "El apellido es requerido")
    @Size(max = 80)
    String apellido;

    @NotBlank(message = "El email es requerido")
    @Email(message = "Email inválido")
    String email;

    @Size(min = 8, message = "La contraseña debe tener al menos 8 caracteres")
    String password;

    private User.Role role;
}
