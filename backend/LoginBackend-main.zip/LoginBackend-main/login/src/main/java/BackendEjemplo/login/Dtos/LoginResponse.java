package BackendEjemplo.login.Dtos;

import BackendEjemplo.login.model.User;
import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class LoginResponse {

    private String token;
    private String type= "Bearer";
    private Long id;
    private String nombre;
    private String apellido;
    private String email;
    private String role;

    public  LoginResponse(String token, User user) {
        this.token    = token;
        this.type     = "Bearer";
        this.id       = user.getIdUser();
        this.nombre   = user.getNombre();
        this.apellido = user.getApellido();
        this.email    = user.getEmail();
        this.role     = user.getRole().name();
    }
    // Corregido: Se agregó el método estático 'from' para mapear el modelo User al DTO
    public static UserResponse from(User user) {
        if (user == null) {
            return null;
        }
        return new UserResponse(
                user.getIdUser(), // Mapea con el ID real de tu entidad User
                user.getNombre(),
                user.getApellido(),
                user.getEmail()
        );
    }

}
