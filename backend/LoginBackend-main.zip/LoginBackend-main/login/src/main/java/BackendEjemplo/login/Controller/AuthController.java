package BackendEjemplo.login.Controller;

import BackendEjemplo.login.Dtos.LoginRequest;
import BackendEjemplo.login.Dtos.LoginResponse;
import BackendEjemplo.login.Dtos.UserRequest;
import BackendEjemplo.login.Service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final AuthService authService;

    /**
     * POST /api/auth/registrar
     * Body: { nombre, apellido, email, password, role }
     * Devuelve token JWT + datos del usuario
     */
    @PostMapping("/registrar")
    public ResponseEntity<LoginResponse> registrar(@Valid @RequestBody UserRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.registrar(request));
    }

    /**
     * POST /api/auth/login
     * Body: { email, password }
     * Devuelve token JWT + datos del usuario
     */
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
}
